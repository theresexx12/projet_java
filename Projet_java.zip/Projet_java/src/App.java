
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

import entities.Classe;
import entities.Etudiant;
import entities.Professeur;
import services.ClasseService;
import services.EtudiantService;
import services.ProfesseurService;
import repositories.ClasseRepository;
import repositories.IClasse;



public class App {

    /**
     * @param args
     * @throws Exception
     */
    public static void main(String[] args) throws Exception {
        int choix;
        Scanner sc=new Scanner(System.in);
        IClasse classeRepository=(IClasse) new ClasseRepository();
        ClasseService classeService=new ClasseService(classeRepository);
        ProfesseurService professeurService=new ProfesseurService();
        EtudiantService etudiantService = new EtudiantService();
        
        
        do {
            System.out.println("1-Créer une classe");
            System.out.println("2-Lister les classes"); 
            System.out.println("3-Ajouter un professeur"); 
            System.out.println("4-Lister les professeurs");
            System.out.println("5-Affecter une classe au professeur"); 
            System.out.println("6-Filtrer les classes d'un professeur"); 
            System.out.println("7-Inscrire ou réinscrire un étudiant");
            System.out.println("8-Lister les étudiants");
            System.out.println("9-Filtrer les étudiants par classe");         
            System.out.println("10-Quitter"); 
             choix=sc.nextInt();
             sc.nextLine();
            switch (choix) {
                case 1:
                System.out.println("Entrer l'id de la classe");
                int id=sc.nextInt(); 
                System.out.println("Entrer le libelle de la classe");
                String nom=sc.next();  
                Classe cl=new Classe();
                 cl.setId(id);
                 cl.setLibelle(nom);
                break;
                case 2:
                List<Classe> classes=  classeService.listerClasses();
                     for (Classe classe: classes) {
                          System.out.println("Id "+ classe.getId());
                          System.out.println("Libelle "+ classe.getLibelle());                         
                          System.out.println("*****************************");
                     }
                break;
               
                case 3:
                System.out.println("Entrer l'id du professeur");
                id=sc.nextInt(); 
                System.out.println("Entrer le NCI du professeur");
                String nci=sc.next();  
                System.out.println("Entrer le nom complet du professeur");
                String nomComplet=sc.next(); 
                System.out.println("Entrer le grade du professeur");
                String grade=sc.next();  
                Professeur pr=new Professeur();
                 pr.setId(id);
                 pr.setNci(nci);
                 pr.setNomComplet(nomComplet);
                 pr.setGrade(grade);
                break;
                case 4:
                List<Professeur> professeurs=  professeurService.listerProfesseurs();
                for (Professeur professeur: professeurs) {
                     System.out.println("Id "+ professeur.getId());
                     System.out.println("Libelle "+ professeur.getNci());
                     System.out.println("Nom Complet "+ professeur.getNomComplet());
                     System.out.println("Grade "+ professeur.getGrade());                     
                     System.out.println("****************************");
                }
                break;
                case 5:
                List<Classe> classes2=  classeService.affecterClasse();  
                for (Classe classe: classes2) {
                    System.out.println("Entrer l'id de la classe");
                id=sc.nextInt(); 
                System.out.println("Entrer le libelle de la classe");
                nom=sc.next();  
                Classe cla=new Classe();
                 cla.setId(id);
                 cla.setLibelle(nom);
                }
                break;
                case 6:
                System.out.println("Entrer l'id du professeur");
                id=sc.nextInt(); 
                List<Professeur> professeurs2 = new ArrayList<>();
                for (Professeur professeur: professeurs2) {
                System.out.println("Id "+ professeur.getId());
                System.out.println("****************************");
                }
                break;
                case 7:
                System.out.println("Entrer l'id de l'etudiant");
                id=sc.nextInt(); 
                System.out.println("Entrer le matricule de l'etudiant");
                String matricule=sc.next();  
                System.out.println("Entrer le nom complet de l'etudiant");
                nomComplet=sc.next(); 
                System.out.println("Entrer le tuteur de l'etudiant");
                String tuteur=sc.next();  
                Etudiant et=new Etudiant();
                 et.setId(id);
                 et.setMatricule(matricule);
                 et.setNomComplet(nomComplet);
                 et.setTuteur(tuteur);
                break;
                case 8:
                List<Etudiant> etudiants=  etudiantService.listerEtudiants();
                for (Etudiant etudiant: etudiants) {
                     System.out.println("Id "+ etudiant.getId());
                     System.out.println("Libelle "+ etudiant.getMatricule());
                     System.out.println("Nom Complet "+ etudiant.getNomComplet());
                     System.out.println("Grade "+ etudiant.getTuteur());                     
                     System.out.println("****************************");
                }
                break;
                case 9:
                System.out.println("Entrer l'id de la classe de l'etudiant");
                id=sc.nextInt(); 
                List<Etudiant> etudiants2 = new ArrayList<>();
                for (Etudiant etudiant: etudiants2) {
                System.out.println("Id "+ etudiant.getId());
                System.out.println("****************************");
                }
                break;
            }
        }while(choix!=10); 
        sc.close();
    }
}
