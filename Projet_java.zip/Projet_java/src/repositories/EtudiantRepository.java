package repositories;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entities.Etudiant;


public class EtudiantRepository extends Database{

    private final  String SQL_SELECT_ALL="SELECT * FROM `etudiant`" ;
    private final  String SQL_INSERT="INSERT INTO etudiant (idEtudiant,matriculeEtudiant,nomCompletEtudiant,tuteurEtudiant) VALUES (?,?,?,?)";
    
    
    public void inscrireEtudiant(Etudiant etudiant){
        openConnexion();
        try {
            initPreparedStatement(SQL_INSERT);
            statement.setInt(1, etudiant.getId());
            statement.setString(2, etudiant.getMatricule());
            statement.setString(1, etudiant.getNomComplet());
            statement.setString(2, etudiant.getTuteur());
            
            closeConnexion();
         } catch (SQLException e) {
          e.printStackTrace();
         }
    }
    public List<Etudiant> getAllEtudiants(){
         List<Etudiant> etudiants=new ArrayList<>();
       try {
           openConnexion();
           initPreparedStatement(SQL_SELECT_ALL);
           ResultSet rs= executeSelect();
             while (rs.next()) {
                 Etudiant et=new Etudiant();
                 et.setId(rs.getInt("id_cl"));
                 et.setMatricule(rs.getString("libelle_cl"));      
                etudiants.add(et);
             }
             rs.close();
           closeConnexion();
        }
       catch (SQLException e) {
        System.out.println("Erreur de Connexion a la BD");
      }
        return  etudiants;
    }
    public Etudiant getEtudiantByClasse(int id) throws SQLException{
      
      try {
        openConnexion();
        initPreparedStatement(SQL_SELECT_ALL);
        ResultSet rs= executeSelect();
          while (rs.next()) {
            Etudiant etudiant = new Etudiant();
              return etudiant.getEtudiantByClasse(id);
          }
            rs.close();
          closeConnexion();
	    }
      catch (SQLException e) {
        System.out.println("Erreur de Connexion a la BD");
    }
      return null;
  }
}

