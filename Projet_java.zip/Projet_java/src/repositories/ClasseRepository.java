package repositories;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import entities.Classe;

public class ClasseRepository extends Database{
    private final  String SQL_SELECT_ALL="SELECT * FROM `classe`" ;
    private final  String SQL_INSERT="INSERT INTO classe (idClasse,libelleClasse) VALUES (?,?)";
    
    
    public void creerClasse(Classe classe){
        openConnexion();
        try {
            initPreparedStatement(SQL_INSERT);
            statement.setInt(1, classe.getId());
            statement.setString(2, classe.getLibelle());
            closeConnexion();
         } catch (SQLException e) {
          e.printStackTrace();
         }
    }
    public List<Classe> getAllClasses(){
         List<Classe> classe=new ArrayList<>();
       try {
           openConnexion();
           initPreparedStatement(SQL_SELECT_ALL);
           ResultSet rs= executeSelect();
             while (rs.next()) {
                 Classe cl=new Classe();
                 cl.setId(rs.getInt("id_cl"));
                 cl.setLibelle(rs.getString("libelle_cl"));      
                classe.add(cl);
             }
             rs.close();
           closeConnexion();
        }
       catch (SQLException e) {
        System.out.println("Erreur de Connexion a la BD");
      }
        return  classe;
    }
    public List<Classe> addClassesByProf(){
      List<Classe> classe=new ArrayList<>();
    try {
        openConnexion();
        initPreparedStatement(SQL_SELECT_ALL);
        ResultSet rs= executeSelect();
          while (rs.next()) {
              Classe cl=new Classe();
              cl.setId(rs.getInt("id_cl"));
              cl.setLibelle(rs.getString("libelle_cl"));      
             classe.add(cl);
          }
          rs.close();
        closeConnexion();
     }
    catch (SQLException e) {
     System.out.println("Erreur de Connexion a la BD");
   }
     return  classe;
 }
}
