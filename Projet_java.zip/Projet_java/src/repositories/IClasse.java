package repositories;

import java.util.List;
import entities.Classe;

public interface IClasse {

    List<Classe> selectAll() ; 
    void insert(Classe classe);
    void creerClasse(Classe classe);
    List<Classe> getAllClasses();
    List<Classe> addClassesByProf();

    
}
