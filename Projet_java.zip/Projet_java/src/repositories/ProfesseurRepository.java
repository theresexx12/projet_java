package repositories;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;


import entities.Professeur;

public class ProfesseurRepository extends Database{
     private final  String SQL_SELECT_ALL="select * from professeur" ;
     private final  String SQL_INSERT="INSERT INTO professeur (idProfesseur,nciProfesseur,nomCompletProfesseur,gradeProfesseur) VALUES (?,?,?,?)";
    
    
    public void creerProfesseur(Professeur professeur){
        openConnexion();
        try {
           openConnexion();
            initPreparedStatement(SQL_INSERT);
            statement.setInt(1, professeur.getId());
            statement.setString(2, professeur.getNci());
            statement.setString(2, professeur.getNomComplet());
            statement.setString(2, professeur.getGrade());
            closeConnexion();
         } catch (SQLException e) {
          e.printStackTrace();
         }
    }
    public List<Professeur> getAllProfesseurs(){
         List<Professeur> professeur=new ArrayList<>();
       try {
           openConnexion();
           initPreparedStatement(SQL_SELECT_ALL);
           ResultSet rs= executeSelect();
             while (rs.next()) {
                 Professeur pr=new Professeur();
                 pr.setId(rs.getInt("id_pr"));
                 pr.setNci(rs.getString("nci_pr"));   
                 pr.setNomComplet(rs.getString("nomComplet_pr"));  
                 pr.setGrade(rs.getString("grade_pr"));     
                professeur.add(pr);
             }
             rs.close();
           closeConnexion();
        }
        
       catch (SQLException e) {
        System.out.println("Erreur de Connexion a la BD");
      }
        return  professeur;
    }
    public Professeur getProfesseurById(int id) throws SQLException{
      
      try {
        openConnexion();
        initPreparedStatement(SQL_SELECT_ALL);
        ResultSet rs= executeSelect();
          while (rs.next()) {
            Professeur professeur = new Professeur();
              return professeur.getProfesseurById(id);
          }
            rs.close();
          closeConnexion();
	    }
      catch (SQLException e) {
        System.out.println("Erreur de Connexion a la BD");
    }
      return null;
  }
}
