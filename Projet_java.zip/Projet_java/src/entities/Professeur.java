package entities;

public class Professeur {
    private int id;
    private String nci;
    private String nomComplet;
    private String grade;
    private Classe classe;

    public Classe getClasse() {
        return classe;
    }

    public void setClasse(Classe classe) {
        this.classe = classe;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getNci() {
        return nci;
    }

    public void setNci(String nci) {
        this.nci = nci;
    }

    public String getNomComplet() {
        return nomComplet;
    }

    public void setNomComplet(String nomComplet) {
        this.nomComplet = nomComplet;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String grade) {
        this.grade = grade;
    }

    // Méthode non implémentée
    public Professeur getProfesseurById(int id2) {
        throw new UnsupportedOperationException("Unimplemented method 'getProfesseurById'");
    }
}
