package entities;

import java.util.ArrayList;
import java.util.List;

public class Classe {
    private int id;
    private String libelle;
    
   
    List<Etudiant> etudiants=new ArrayList<>();
    public List<Etudiant> getEtudiants() {
        return etudiants;
    }

    public void setEtudiant(List<Etudiant> etudiants) {
        this.etudiants = etudiants;
    }

    List<Professeur> professeurs=new ArrayList<>();
    public List<Professeur> getProfesseurs() {
        return professeurs;
    }

    public void setProfesseur(List<Professeur> professeurs) {
        this.professeurs = professeurs;
    }

    public Professeur professeur;

    public Classe() {
    }

    public Professeur getProfesseur() {
        return professeur;
    }

    public void setProfesseur(Professeur professeur) {
        this.professeur = professeur;
    }

    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getLibelle() {
        return libelle;
    }
    public void setLibelle(String libelle) {
        this.libelle = libelle;
    }
   
    
}
