package services;

import java.util.List;


import entities.Professeur;
import repositories.ProfesseurRepository;

public class ProfesseurService {
    private ProfesseurRepository professeurRepository= new ProfesseurRepository();
    

     public void ajouterProfesseur(Professeur professeur){
        professeurRepository.creerProfesseur(professeur);
    }
    public List<Professeur> listerProfesseurs(){
       return professeurRepository.getAllProfesseurs();
    }
    public List<Professeur> getProfesseurById(){
       return professeurRepository.getAllProfesseurs();
    }
}
