package services;

import java.util.List;

import entities.Classe;

import repositories.IClasse;

public class ClasseService {
    private IClasse classeRepository;
    public ClasseService(IClasse classeRepository) {
       this.classeRepository = classeRepository;
    }
    
    

     public void ajouterClasse(Classe classe){
        classeRepository.creerClasse(classe);
    }
    public List<Classe> listerClasses(){
       return classeRepository.getAllClasses();
    }
    public List<Classe> affecterClasse(){
        return classeRepository.addClassesByProf();
     }
}
