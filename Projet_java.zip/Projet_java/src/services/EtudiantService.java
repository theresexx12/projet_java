package services;

import java.util.List;


import entities.Etudiant;
import repositories.EtudiantRepository;


public class EtudiantService {
    private EtudiantRepository etudiantRepository= new EtudiantRepository();
    

     public void inscrireEtudiant(Etudiant etudiant){
        etudiantRepository.inscrireEtudiant(etudiant);
    }
    public List<Etudiant> listerEtudiants(){
       return etudiantRepository.getAllEtudiants();
    }
    public List<Etudiant> getEtudiantByClasse(){
        return etudiantRepository.getAllEtudiants();
     }
}
